print('extractor')
